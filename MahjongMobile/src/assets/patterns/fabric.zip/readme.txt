
TERMS OF USE:

 All resources may be used for both personal and commercial projects. 
You may freely use them in software programs, web templates, posters, CD covers, book covers, photo manipulations and other materials intended for sale or distribution. No attribution required. You may modify the resources according to your requirements and use them free in any or all of your personal and commercial projects. 

You are not permitted to resell or redistribute the original files without prior consent.


____________________________

www.ideasplayer.com